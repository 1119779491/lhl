from rest_framework import generics, permissions
from rest_framework.response import Response
from django.db.models import Count, Avg
from apps.users.models import User
from apps.movies.models import Movie
from apps.interactions.models import Rating, Review


class UserStatsView(generics.GenericAPIView):
    permission_classes = [permissions.IsAdminUser]

    def get(self, request, *args, **kwargs):
        total_users = User.objects.count()
        active_users = User.objects.filter(is_active=True).count()
        avg_ratings_per_user = Rating.objects.values('user').annotate(
            count=Count('id')).aggregate(avg=Avg('count'))['avg'] or 0

        return Response({
            'total_users': total_users,
            'active_users': active_users,
            'avg_ratings_per_user': round(avg_ratings_per_user, 2)
        })


class MovieStatsView(generics.GenericAPIView):
    permission_classes = [permissions.IsAdminUser]

    def get(self, request, *args, **kwargs):
        total_movies = Movie.objects.count()
        avg_rating = Movie.objects.aggregate(avg=Avg('avg_rating'))['avg'] or 0
        top_rated_movies = Movie.objects.order_by('-avg_rating')[:5].values('title', 'avg_rating')

        return Response({
            'total_movies': total_movies,
            'avg_rating': round(avg_rating, 2),
            'top_rated_movies': top_rated_movies
        })