from django.urls import path
from .views import UserStatsView, MovieStatsView

urlpatterns = [
    path('user-stats/', UserStatsView.as_view(), name='user-stats'),
    path('movie-stats/', MovieStatsView.as_view(), name='movie-stats'),
]