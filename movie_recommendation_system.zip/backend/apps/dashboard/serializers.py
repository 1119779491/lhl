from rest_framework import serializers
from apps.movies.models import Movie

class MovieStatsSerializer(serializers.Serializer):
    total_movies = serializers.IntegerField()
    avg_rating = serializers.DecimalField(max_digits=3, decimal_places=2)
    top_rated_movies = serializers.ListField(child=serializers.DictField())