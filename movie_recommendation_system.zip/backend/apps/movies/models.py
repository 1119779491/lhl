from django.db import models
import uuid


class Genre(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=30, unique=True)

    class Meta:
        db_table = 'genre'
        ordering = ['name']

    def __str__(self):
        return self.name


class Movie(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    title = models.CharField(max_length=100)
    description = models.TextField()
    release_year = models.IntegerField()
    director = models.CharField(max_length=50)
    duration = models.IntegerField()  # 分钟
    poster_url = models.URLField(max_length=255)
    trailer_url = models.URLField(max_length=255, blank=True, null=True)
    avg_rating = models.DecimalField(max_digits=3, decimal_places=2, default=0.0)
    genres = models.ManyToManyField(Genre, related_name='movies')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'movie'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['title']),
            models.Index(fields=['avg_rating']),
            models.Index(fields=['release_year']),
        ]

    def __str__(self):
        return self.title

    def update_avg_rating(self):
        from apps.interactions.models import Rating
        ratings = Rating.objects.filter(movie=self)
        if ratings.exists():
            self.avg_rating = ratings.aggregate(models.Avg('rating_value'))['rating_value__avg']
            self.save()