from rest_framework import serializers
from .models import Movie, Genre


class GenreSerializer(serializers.ModelSerializer):
    class Meta:
        model = Genre
        fields = ['id', 'name']


class MovieSerializer(serializers.ModelSerializer):
    genres = GenreSerializer(many=True, read_only=True)

    class Meta:
        model = Movie
        fields = [
            'id', 'title', 'description', 'release_year',
            'director', 'duration', 'poster_url', 'trailer_url',
            'avg_rating', 'genres', 'created_at', 'updated_at'
        ]
        read_only_fields = ['avg_rating', 'created_at', 'updated_at']