from django.urls import path
from .views import MovieListView, MovieDetailView, GenreListView, SearchMoviesView

urlpatterns = [
    path('', MovieListView.as_view(), name='movie-list'),
    path('<uuid:id>/', MovieDetailView.as_view(), name='movie-detail'),
    path('genres/', GenreListView.as_view(), name='genre-list'),
    path('search/', SearchMoviesView.as_view(), name='movie-search'),
]