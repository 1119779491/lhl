from rest_framework import generics, permissions
from rest_framework.response import Response
from .algorithms.content_based import ContentBasedRecommender
from .algorithms.collaborative import CollaborativeRecommender
from apps.movies.models import Movie
from apps.interactions.models import ViewHistory
from .tasks import generate_recommendations
import random


class RecommendationView(generics.GenericAPIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, *args, **kwargs):
        user = request.user

        # 获取用户最近观看的电影
        recent_views = ViewHistory.objects.filter(user=user).order_by('-viewed_at')[:3]
        recent_movie_ids = [view.movie_id for view in recent_views]

        # 如果没有观看历史，使用热门电影
        if not recent_movie_ids:
            popular_movies = Movie.objects.order_by('-avg_rating')[:20]
            return Response({
                'recommendations': [movie.id for movie in popular_movies[:10]],
                'algorithm': 'popular'
            })

        # 尝试基于内容的推荐
        content_recommender = ContentBasedRecommender()
        content_recommender.train()

        content_recs = []
        for movie_id in recent_movie_ids:
            recs = content_recommender.recommend(movie_id, top_n=5)
            content_recs.extend(recs)

        # 去重
        content_recs = list(set(content_recs))

        # 如果基于内容的推荐足够，返回结果
        if len(content_recs) >= 10:
            return Response({
                'recommendations': content_recs[:10],
                'algorithm': 'content-based'
            })

        # 尝试协同过滤推荐
        collab_recommender = CollaborativeRecommender()
        collab_recommender.train()

        collab_recs = collab_recommender.recommend(user.id, top_n=15)

        # 合并结果并去重
        combined_recs = list(set(content_recs + collab_recs))

        # 如果结果不足，补充热门电影
        if len(combined_recs) < 10:
            popular_movies = Movie.objects.order_by('-avg_rating').exclude(id__in=combined_recs)[:10]
            combined_recs.extend([movie.id for movie in popular_movies])

        # 打乱顺序后返回前10个
        random.shuffle(combined_recs)
        return Response({
            'recommendations': combined_recs[:10],
            'algorithm': 'hybrid'
        })


class GenerateRecommendationsView(generics.GenericAPIView):
    permission_classes = [permissions.IsAdminUser]

    def post(self, request, *args, **kwargs):
        # 异步生成推荐
        generate_recommendations.delay()
        return Response({"status": "Recommendation generation started"})