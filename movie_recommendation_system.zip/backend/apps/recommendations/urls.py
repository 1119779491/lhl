from django.urls import path
from .views import RecommendationView, GenerateRecommendationsView

urlpatterns = [
    path('', RecommendationView.as_view(), name='recommendations'),
    path('generate/', GenerateRecommendationsView.as_view(), name='generate-recommendations'),
]