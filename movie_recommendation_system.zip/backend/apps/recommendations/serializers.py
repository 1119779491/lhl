from rest_framework import serializers
from apps.movies.serializers import MovieSerializer

class RecommendationSerializer(serializers.Serializer):
    movie = MovieSerializer()
    algorithm = serializers.CharField()
    score = serializers.FloatField()