from django.db import models
from apps.users.models import User
from apps.movies.models import Movie
import uuid


class Recommendation(models.Model):
    ALGORITHM_CHOICES = [
        ('content', 'Content-Based'),
        ('collab', 'Collaborative Filtering'),
        ('hybrid', 'Hybrid'),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='recommendations')
    movie = models.ForeignKey(Movie, on_delete=models.CASCADE, related_name='recommendations')
    algorithm_type = models.CharField(max_length=20, choices=ALGORITHM_CHOICES)
    score = models.DecimalField(max_digits=5, decimal_places=4, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'recommendation'
        ordering = ['-created_at']
        unique_together = ('user', 'movie', 'algorithm_type')