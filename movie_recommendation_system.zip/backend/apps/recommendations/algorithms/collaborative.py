import numpy as np
from scipy.sparse import coo_matrix, csr_matrix
from sklearn.neighbors import NearestNeighbors
from apps.interactions.models import Rating
from apps.users.models import User
from apps.movies.models import Movie


class CollaborativeRecommender:
    def __init__(self, n_neighbors=20):
        self.n_neighbors = n_neighbors
        self.model = None
        self.user_mapping = None
        self.movie_mapping = None

    def train(self):
        # 获取所有评分数据
        ratings = Rating.objects.all().select_related('user', 'movie')
        if not ratings.exists():
            return

        # 创建用户和电影的映射
        users = User.objects.all()
        movies = Movie.objects.all()
        self.user_mapping = {user.id: idx for idx, user in enumerate(users)}
        self.movie_mapping = {movie.id: idx for idx, movie in enumerate(movies)}

        # 创建评分矩阵
        user_indices = [self.user_mapping[r.user_id] for r in ratings]
        movie_indices = [self.movie_mapping[r.movie_id] for r in ratings]
        ratings_data = [r.rating_value for r in ratings]

        # 创建稀疏矩阵 - 修复这里的语法错误
        rating_matrix = coo_matrix(
            (ratings_data, (user_indices, movie_indices)),
            shape=(len(users), len(movies))
        )
        rating_matrix = rating_matrix.tocsr()

        # 训练KNN模型
        self.model = NearestNeighbors(metric='cosine', algorithm='brute', n_neighbors=self.n_neighbors)
        self.model.fit(rating_matrix)

    def recommend(self, user_id, top_n=10):
        if not self.model or user_id not in self.user_mapping:
            return []

        user_idx = self.user_mapping[user_id]
        ratings = Rating.objects.filter(user_id=user_id).select_related('movie')

        # 获取用户向量
        user_vector = csr_matrix((1, len(self.movie_mapping)))

        # 填充用户评分
        for rating in ratings:
            if rating.movie_id in self.movie_mapping:
                movie_idx = self.movie_mapping[rating.movie_id]
                user_vector[0, movie_idx] = rating.rating_value

        # 查找相似用户
        distances, indices = self.model.kneighbors(user_vector, n_neighbors=self.n_neighbors)

        # 获取推荐电影
        similar_users = indices[0]
        movie_scores = {}

        for user_idx in similar_users:
            # 这里需要修复：self.user_mapping 是 user_id 到索引的映射
            # 我们需要反向映射找到用户ID
            user_id_rev = next((uid for uid, idx in self.user_mapping.items() if idx == user_idx), None)
            if not user_id_rev:
                continue

            user_ratings = Rating.objects.filter(user_id=user_id_rev)
            for rating in user_ratings:
                if rating.movie_id not in movie_scores:
                    movie_scores[rating.movie_id] = []
                movie_scores[rating.movie_id].append(rating.rating_value)

        # 计算平均评分
        for movie_id, scores in movie_scores.items():
            movie_scores[movie_id] = sum(scores) / len(scores)

        # 按评分排序并返回top_n
        sorted_movies = sorted(movie_scores.items(), key=lambda x: x[1], reverse=True)[:top_n]
        return [movie_id for movie_id, _ in sorted_movies]