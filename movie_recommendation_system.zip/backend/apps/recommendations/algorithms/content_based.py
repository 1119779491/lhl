from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel
from apps.movies.models import Movie
import numpy as np


class ContentBasedRecommender:
    def __init__(self):
        self.tfidf = TfidfVectorizer(stop_words='english')
        self.cosine_sim = None
        self.movies = None
        self.indices = None

    def train(self):
        # 获取所有电影数据
        self.movies = list(Movie.objects.all())
        movie_data = [
            f"{movie.title} {movie.description} {movie.director} {' '.join([g.name for g in movie.genres.all()])}"
            for movie in self.movies]

        # 创建TF-IDF矩阵
        tfidf_matrix = self.tfidf.fit_transform(movie_data)

        # 计算余弦相似度
        self.cosine_sim = linear_kernel(tfidf_matrix, tfidf_matrix)

        # 创建电影索引
        self.indices = {movie.id: idx for idx, movie in enumerate(self.movies)}

    def recommend(self, movie_id, top_n=10):
        if movie_id not in self.indices:
            return []

        idx = self.indices[movie_id]
        sim_scores = list(enumerate(self.cosine_sim[idx]))
        sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)
        sim_scores = sim_scores[1:top_n + 1]  # 排除自身

        movie_indices = [i[0] for i in sim_scores]
        return [self.movies[i].id for i in movie_indices]