from django.urls import path
from .views import (
    RatingCreateView, ReviewCreateView, ViewHistoryCreateView,
    UserRatingsView, UserReviewsView, UserViewHistoryView
)

urlpatterns = [
    path('ratings/', RatingCreateView.as_view(), name='rating-create'),
    path('reviews/', ReviewCreateView.as_view(), name='review-create'),
    path('history/', ViewHistoryCreateView.as_view(), name='history-create'),
    path('my-ratings/', UserRatingsView.as_view(), name='user-ratings'),
    path('my-reviews/', UserReviewsView.as_view(), name='user-reviews'),
    path('my-history/', UserViewHistoryView.as_view(), name='user-history'),
]