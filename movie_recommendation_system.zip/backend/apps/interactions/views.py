from rest_framework import generics, permissions
from .models import Rating, Review, ViewHistory
from .serializers import RatingSerializer, ReviewSerializer, ViewHistorySerializer
from apps.movies.models import Movie
from django.utils import timezone


class RatingCreateView(generics.CreateAPIView):
    queryset = Rating.objects.all()
    serializer_class = RatingSerializer
    permission_classes = [permissions.IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)


class ReviewCreateView(generics.CreateAPIView):
    queryset = Review.objects.all()
    serializer_class = ReviewSerializer
    permission_classes = [permissions.IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)


class ViewHistoryCreateView(generics.CreateAPIView):
    queryset = ViewHistory.objects.all()
    serializer_class = ViewHistorySerializer
    permission_classes = [permissions.IsAuthenticated]

    def perform_create(self, serializer):
        movie_id = self.request.data.get('movie')
        movie = Movie.objects.get(id=movie_id)
        # 检查是否已有观看记录
        existing_view = ViewHistory.objects.filter(
            user=self.request.user,
            movie=movie
        ).first()

        if existing_view:
            existing_view.viewed_at = timezone.now()
            existing_view.save()
            return existing_view

        return serializer.save(user=self.request.user, movie=movie)


class UserRatingsView(generics.ListAPIView):
    serializer_class = RatingSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Rating.objects.filter(user=self.request.user)


class UserReviewsView(generics.ListAPIView):
    serializer_class = ReviewSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Review.objects.filter(user=self.request.user)


class UserViewHistoryView(generics.ListAPIView):
    serializer_class = ViewHistorySerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return ViewHistory.objects.filter(user=self.request.user).order_by('-viewed_at')