from rest_framework import serializers
from apps.movies.serializers import MovieSerializer
from .models import Rating, Review, ViewHistory


class RatingSerializer(serializers.ModelSerializer):
    class Meta:
        model = Rating
        fields = ['id', 'movie', 'rating_value', 'created_at']
        read_only_fields = ['id', 'created_at']
        extra_kwargs = {
            'movie': {'required': True},
            'rating_value': {'required': True}
        }


class ReviewSerializer(serializers.ModelSerializer):
    class Meta:
        model = Review
        fields = ['id', 'movie', 'content', 'created_at']
        read_only_fields = ['id', 'created_at']
        extra_kwargs = {
            'movie': {'required': True},
            'content': {'required': True}
        }


class ViewHistorySerializer(serializers.ModelSerializer):
    movie = MovieSerializer(read_only=True)

    class Meta:
        model = ViewHistory
        fields = ['id', 'movie', 'viewed_at']
        read_only_fields = ['id', 'viewed_at']
        extra_kwargs = {
            'movie': {'required': True}
        }