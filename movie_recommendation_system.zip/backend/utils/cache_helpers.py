from django.core.cache import cache

def cache_movie_details(movie_id, data, timeout=3600):
    cache_key = f'movie_{movie_id}_details'
    cache.set(cache_key, data, timeout)

def get_cached_movie_details(movie_id):
    cache_key = f'movie_{movie_id}_details'
    return cache.get(cache_key)

def cache_recommendations(user_id, recommendations, timeout=86400):
    cache_key = f'user_{user_id}_recommendations'
    cache.set(cache_key, recommendations, timeout)

def get_cached_recommendations(user_id):
    cache_key = f'user_{user_id}_recommendations'
    return cache.get(cache_key)