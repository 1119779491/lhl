from django.http import JsonResponse

def welcome_view(request):
    return JsonResponse({
        "message": "Welcome to Movie Recommendation System API",
        "endpoints": {
            "api_documentation": "/swagger/",
            "admin_panel": "/admin/",
            "user_registration": "/api/auth/register/",
            "user_login": "/api/auth/login/",
            "movie_list": "/api/movies/",
            "get_recommendations": "/api/recommendations/",
        }
    })