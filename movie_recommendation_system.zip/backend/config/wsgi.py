import os

from django.core.wsgi import get_wsgi_application

# 确保设置正确的模块路径
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')

application = get_wsgi_application()