// test.js
console.log('这是一个测试脚本');
console.log('Node.js 版本:', process.version);