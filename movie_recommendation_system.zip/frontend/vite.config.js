// frontend/vite.config.js
import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import path from 'path'  // 导入path模块

export default defineConfig({
  root: './src',
  plugins: [vue()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src')  // 配置@符号指向src目录
    }
  },
  build: {
    outDir: '../dist'
  }
})