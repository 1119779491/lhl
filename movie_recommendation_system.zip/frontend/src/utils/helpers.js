// 格式化日期
export const formatDate = (dateString) => {
  const options = { year: 'numeric', month: 'long', day: 'numeric' }
  return new Date(dateString).toLocaleDateString(undefined, options)
}

// 格式化时间
export const formatTime = (dateString) => {
  const options = { hour: '2-digit', minute: '2-digit' }
  return new Date(dateString).toLocaleTimeString(undefined, options)
}

// 格式化电影时长
export const formatDuration = (minutes) => {
  const hours = Math.floor(minutes / 60)
  const mins = minutes % 60
  return `${hours ? `${hours}h ` : ''}${mins}m`
}

// 处理图片加载错误
export const handleImageError = (e, placeholder) => {
  e.target.src = placeholder || 'https://via.placeholder.com/300x450?text=No+Image'
}

// ... 其他函数 ...

// 格式化日期时间
export const formatDateTime = (dateString) => {
  if (!dateString) return ''
  const date = new Date(dateString)
  return `${date.toLocaleDateString()} ${date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`
}