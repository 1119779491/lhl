import { useAuthStore } from '@/store/auth'

// 设置请求拦截器添加认证令牌
export const setupAuthInterceptor = (axiosInstance) => {
  axiosInstance.interceptors.request.use(config => {
    const authStore = useAuthStore()
    if (authStore.token) {
      config.headers.Authorization = `Token ${authStore.token}`
    }
    return config
  })

  // 响应拦截器处理401未授权
  axiosInstance.interceptors.response.use(
    response => response,
    error => {
      if (error.response && error.response.status === 401) {
        const authStore = useAuthStore()
        authStore.logout()
        // 可以在这里添加重定向到登录页的逻辑
      }
      return Promise.reject(error)
    }
  )
}

// 检查用户是否认证
export const isAuthenticated = () => {
  const authStore = useAuthStore()
  return authStore.isAuthenticated
}

// 获取当前用户
export const getCurrentUser = () => {
  const authStore = useAuthStore()
  return authStore.user
}