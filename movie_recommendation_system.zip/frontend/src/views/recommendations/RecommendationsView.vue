<template>
  <div class="recommendations-container">
    <h2 class="section-title">为您推荐的电影</h2>

    <div v-if="loading" class="loading-container">
      <LoadingSpinner />
    </div>

    <div v-else-if="error" class="error-container">
      <ErrorMessage :message="error" />
    </div>

    <div v-else>
      <div v-if="recommendations.length === 0" class="empty-state">
        <EmptyState
          message="暂无推荐，请先评价一些电影"
          action-text="生成推荐"
          @action="generateRecommendations"
        />
      </div>

      <div v-else class="recommendation-grid">
        <MovieCard
          v-for="rec in recommendations"
          :key="rec.movie.id"
          :movie="rec.movie"
          @click="viewMovieDetail(rec.movie.id)"
        />
      </div>

      <div class="recommendation-footer">
        <el-button
          type="primary"
          @click="generateRecommendations"
          :loading="generating"
        >
          刷新推荐
        </el-button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useRecommendationStore } from '@/store/recommendations'
import MovieCard from '@/components/movie/MovieCard.vue'
import LoadingSpinner from '@/components/common/LoadingSpinner.vue'
import ErrorMessage from '@/components/common/ErrorMessage.vue'
import EmptyState from '@/components/common/EmptyState.vue'
import { ElMessage } from 'element-plus'

const recommendationStore = useRecommendationStore()
const router = useRouter()

const recommendations = computed(() => recommendationStore.recommendations)
const loading = computed(() => recommendationStore.loading)
const error = computed(() => recommendationStore.error)
const generating = ref(false)

const viewMovieDetail = (movieId) => {
  router.push({ name: 'movie-detail', params: { id: movieId } })
}

const generateRecommendations = async () => {
  generating.value = true
  try {
    await recommendationStore.generateRecommendations()
    await recommendationStore.fetchRecommendations()
    ElMessage.success('推荐已更新')
  } catch (err) {
    ElMessage.error('生成推荐失败')
    console.error(err)
  } finally {
    generating.value = false
  }
}

onMounted(async () => {
  await recommendationStore.fetchRecommendations()
})
</script>

<style scoped>
.recommendations-container {
  padding: 30px 20px;
  max-width: 1400px;
  margin: 0 auto;
}

.section-title {
  text-align: center;
  margin-bottom: 30px;
  font-size: 24px;
  color: #303133;
}

.recommendation-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
  gap: 25px;
}

.loading-container,
.error-container,
.empty-state {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 300px;
}

.recommendation-footer {
  display: flex;
  justify-content: center;
  margin-top: 40px;
}
</style>