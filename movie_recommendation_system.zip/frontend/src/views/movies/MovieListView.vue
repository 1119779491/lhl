<template>
  <div class="movie-list-container">
    <div class="filters">
      <el-input
        v-model="searchQuery"
        placeholder="搜索电影..."
        class="search-input"
        @input="handleSearch"
      />
      <el-select v-model="selectedGenre" placeholder="选择类型" @change="filterMovies">
        <el-option
          v-for="genre in genres"
          :key="genre.id"
          :label="genre.name"
          :value="genre.id"
        />
      </el-select>
    </div>

    <div v-if="loading" class="loading-container">
      <LoadingSpinner />
    </div>

    <div v-else-if="error" class="error-container">
      <ErrorMessage :message="error" />
    </div>

    <div v-else>
      <div v-if="filteredMovies.length === 0" class="empty-state">
        <EmptyState message="没有找到匹配的电影" />
      </div>

      <div v-else class="movie-grid">
        <MovieCard
          v-for="movie in paginatedMovies"
          :key="movie.id"
          :movie="movie"
          @click="viewMovieDetail(movie.id)"
        />
      </div>

      <div class="pagination-container">
        <el-pagination
          v-model:current-page="currentPage"
          :page-size="pageSize"
          layout="prev, pager, next"
          :total="filteredMovies.length"
          @current-change="handlePageChange"
        />
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, watch } from 'vue'
import { useRouter } from 'vue-router'
import { useMovieStore } from '@/store/movies'
import MovieCard from '@/components/movie/MovieCard.vue'
import LoadingSpinner from '@/components/common/LoadingSpinner.vue'
import ErrorMessage from '@/components/common/ErrorMessage.vue'
import EmptyState from '@/components/common/EmptyState.vue'

const movieStore = useMovieStore()
const router = useRouter()

const searchQuery = ref('')
const selectedGenre = ref('')
const currentPage = ref(1)
const pageSize = ref(12)

// 从store获取数据
const movies = computed(() => movieStore.movies)
const genres = computed(() => movieStore.genres)
const loading = computed(() => movieStore.loading)
const error = computed(() => movieStore.error)

// 计算过滤后的电影
const filteredMovies = computed(() => {
  return movies.value.filter(movie => {
    const matchesSearch = movie.title.toLowerCase().includes(searchQuery.value.toLowerCase())
    const matchesGenre = !selectedGenre.value ||
      movie.genres.some(g => g.id === selectedGenre.value)
    return matchesSearch && matchesGenre
  })
})

// 分页数据
const paginatedMovies = computed(() => {
  const start = (currentPage.value - 1) * pageSize.value
  return filteredMovies.value.slice(start, start + pageSize.value)
})

// 搜索防抖
let searchTimeout = null
const handleSearch = () => {
  clearTimeout(searchTimeout)
  searchTimeout = setTimeout(() => {
    if (searchQuery.value.trim()) {
      movieStore.searchMovies(searchQuery.value)
    } else {
      movieStore.fetchMovies()
    }
  }, 500)
}

const filterMovies = () => {
  currentPage.value = 1
}

const viewMovieDetail = (movieId) => {
  router.push({ name: 'movie-detail', params: { id: movieId } })
}

const handlePageChange = (page) => {
  currentPage.value = page
  window.scrollTo({ top: 0, behavior: 'smooth' })
}

onMounted(async () => {
  await movieStore.fetchMovies()
  await movieStore.fetchGenres()
})
</script>

<style scoped>
.movie-list-container {
  padding: 20px;
  max-width: 1400px;
  margin: 0 auto;
}

.filters {
  display: flex;
  gap: 20px;
  margin-bottom: 30px;
}

.search-input {
  flex: 1;
  max-width: 400px;
}

.movie-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
  gap: 25px;
}

.loading-container,
.error-container,
.empty-state {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
}

.pagination-container {
  display: flex;
  justify-content: center;
  margin-top: 40px;
}
</style>