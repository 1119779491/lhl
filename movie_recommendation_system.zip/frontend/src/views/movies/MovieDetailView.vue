<template>
  <div class="movie-detail-container" v-if="movie">
    <div class="movie-header">
      <img :src="movie.poster_url" :alt="movie.title" class="movie-poster" />
      <div class="movie-info">
        <h1>{{ movie.title }}</h1>
        <div class="movie-meta">
          <span>{{ movie.release_year }}</span>
          <span> · </span>
          <span>{{ formatDuration(movie.duration) }}</span>
          <span> · </span>
          <span>导演: {{ movie.director }}</span>
        </div>
        <div class="movie-rating">
          <el-rate
            v-model="userRating"
            :max="5"
            allow-half
            @change="submitRating"
          />
          <span class="avg-rating">平均评分: {{ movie.avg_rating.toFixed(1) }} ({{ ratingCount }}人)</span>
        </div>
        <div class="movie-genres">
          <el-tag
            v-for="genre in movie.genres"
            :key="genre.id"
            type="info"
            class="genre-tag"
          >
            {{ genre.name }}
          </el-tag>
        </div>
        <div class="movie-actions">
          <el-button type="primary" icon="el-icon-video-play" @click="addToHistory">标记为已观看</el-button>
          <el-button icon="el-icon-star-off" @click="showRecommendations">查看类似电影</el-button>
        </div>
      </div>
    </div>

    <div class="movie-content">
      <div class="movie-description">
        <h3>剧情简介</h3>
        <p>{{ movie.description }}</p>
      </div>

      <div v-if="movie.trailer_url" class="movie-trailer">
        <h3>预告片</h3>
        <iframe
          :src="movie.trailer_url"
          frameborder="0"
          allowfullscreen
          class="trailer-iframe"
        ></iframe>
      </div>
    </div>

    <div class="user-interactions">
      <div class="reviews-section">
        <h3>用户评论</h3>
        <div class="review-form">
          <el-input
            v-model="newReview"
            type="textarea"
            placeholder="写下你的评论..."
            rows="3"
          />
          <el-button type="primary" @click="submitReview" class="submit-review">提交评论</el-button>
        </div>

        <div v-if="reviewsLoading" class="loading-container">
          <LoadingSpinner />
        </div>

        <div v-else-if="reviews.length === 0" class="empty-state">
          <EmptyState message="暂无评论，成为第一个评论者吧！" />
        </div>

        <div v-else class="reviews-list">
          <div v-for="review in reviews" :key="review.id" class="review-item">
            <div class="review-header">
              <el-avatar :src="review.user.avatar_url || defaultAvatar" :size="40" />
              <div class="review-user">
                <span class="username">{{ review.user.username }}</span>
                <span class="date">{{ formatDate(review.created_at) }}</span>
              </div>
            </div>
            <div class="review-content">
              <p>{{ review.content }}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div v-else-if="loading" class="loading-container">
    <LoadingSpinner />
  </div>

  <div v-else-if="error" class="error-container">
    <ErrorMessage :message="error" />
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useMovieStore } from '@/store/movies'
import { addRating, addReview, getReviews, addToViewHistory } from '@/api/interactions'
import { formatDate, formatDuration } from '@/utils/helpers'
import { ElMessage } from 'element-plus'
import LoadingSpinner from '@/components/common/LoadingSpinner.vue'
import ErrorMessage from '@/components/common/ErrorMessage.vue'
import EmptyState from '@/components/common/EmptyState.vue'

const route = useRoute()
const router = useRouter()
const movieStore = useMovieStore()

const movie = ref(null)
const userRating = ref(0)
const newReview = ref('')
const reviews = ref([])
const reviewsLoading = ref(false)
const loading = ref(true)
const error = ref(null)
const defaultAvatar = 'https://via.placeholder.com/40'

const ratingCount = computed(() => {
  return movie.value?.ratings_count || 0
})

onMounted(async () => {
  const movieId = route.params.id
  try {
    loading.value = true
    movie.value = await movieStore.fetchMovieDetail(movieId)

    // 检查用户是否已评分
    if (movie.value.user_rating) {
      userRating.value = movie.value.user_rating
    }

    await loadReviews(movieId)
  } catch (err) {
    error.value = '加载电影详情失败'
    console.error(err)
  } finally {
    loading.value = false
  }
})

const loadReviews = async (movieId) => {
  reviewsLoading.value = true
  try {
    const response = await getReviews(movieId)
    reviews.value = response.data
  } catch (err) {
    ElMessage.error('加载评论失败')
    console.error(err)
  } finally {
    reviewsLoading.value = false
  }
}

const submitRating = async (rating) => {
  try {
    await addRating({
      movie: movie.value.id,
      rating_value: rating * 2  // 转换为10分制
    })
    ElMessage.success('评分成功')
    // 重新加载电影详情更新平均分
    movie.value = await movieStore.fetchMovieDetail(movie.value.id)
  } catch (err) {
    ElMessage.error('评分失败')
    console.error(err)
  }
}

const submitReview = async () => {
  if (!newReview.value.trim()) {
    ElMessage.warning('评论内容不能为空')
    return
  }

  try {
    await addReview({
      movie: movie.value.id,
      content: newReview.value
    })
    ElMessage.success('评论成功')
    newReview.value = ''
    await loadReviews(movie.value.id)
  } catch (err) {
    ElMessage.error('评论失败')
    console.error(err)
  }
}

const addToHistory = async () => {
  try {
    await addToViewHistory(movie.value.id)
    ElMessage.success('已添加到观看历史')
  } catch (err) {
    ElMessage.error('添加失败')
    console.error(err)
  }
}

const showRecommendations = () => {
  router.push({ name: 'recommendations' })
}
</script>

<style scoped>
.movie-detail-container {
  max-width: 1200px;
  margin: 30px auto;
  padding: 0 20px;
}

.movie-header {
  display: flex;
  margin-bottom: 40px;
}

.movie-poster {
  width: 300px;
  height: 450px;
  object-fit: cover;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.movie-info {
  flex: 1;
  margin-left: 40px;
}

.movie-info h1 {
  font-size: 32px;
  margin-bottom: 15px;
}

.movie-meta {
  display: flex;
  align-items: center;
  color: #606266;
  margin-bottom: 20px;
  font-size: 16px;
}

.movie-meta span {
  margin-right: 10px;
}

.movie-rating {
  display: flex;
  align-items: center;
  margin-bottom: 25px;
}

:deep(.el-rate) {
  margin-right: 15px;
}

.avg-rating {
  font-size: 16px;
  color: #606266;
}

.movie-genres {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  margin-bottom: 30px;
}

.genre-tag {
  font-size: 14px;
}

.movie-actions {
  display: flex;
  gap: 15px;
}

.movie-content {
  margin-bottom: 50px;
}

.movie-description {
  margin-bottom: 40px;
}

.movie-description h3 {
  font-size: 20px;
  margin-bottom: 15px;
  color: #303133;
}

.movie-description p {
  line-height: 1.8;
  color: #606266;
  font-size: 16px;
}

.movie-trailer {
  margin-bottom: 40px;
}

.movie-trailer h3 {
  font-size: 20px;
  margin-bottom: 15px;
  color: #303133;
}

.trailer-iframe {
  width: 100%;
  height: 500px;
  border-radius: 8px;
}

.user-interactions {
  background-color: #f8f9fa;
  padding: 30px;
  border-radius: 8px;
}

.reviews-section h3 {
  font-size: 20px;
  margin-bottom: 20px;
  color: #303133;
}

.review-form {
  margin-bottom: 30px;
}

.submit-review {
  margin-top: 15px;
}

.review-item {
  background-color: white;
  border-radius: 8px;
  padding: 20px;
  margin-bottom: 20px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
}

.review-header {
  display: flex;
  align-items: center;
  margin-bottom: 15px;
}

.review-user {
  margin-left: 15px;
}

.review-user .username {
  font-weight: bold;
  display: block;
}

.review-user .date {
  font-size: 12px;
  color: #909399;
}

.review-content p {
  line-height: 1.6;
  color: #606266;
}

.loading-container,
.error-container,
.empty-state {
  min-height: 300px;
  display: flex;
  align-items: center;
  justify-content: center;
}

@media (max-width: 768px) {
  .movie-header {
    flex-direction: column;
  }

  .movie-info {
    margin-left: 0;
    margin-top: 30px;
  }

  .movie-poster {
    width: 100%;
    height: auto;
    max-height: 500px;
  }

  .movie-actions {
    flex-direction: column;
  }

  .trailer-iframe {
    height: 300px;
  }
}
</style>