<template>
  <div class="search-view">
    <div class="search-header">
      <el-input
        v-model="searchQuery"
        placeholder="输入电影名称搜索..."
        size="large"
        clearable
        @keyup.enter="searchMovies"
      >
        <template #append>
          <el-button icon="el-icon-search" @click="searchMovies" />
        </template>
      </el-input>
    </div>

    <div class="search-filters">
      <el-select v-model="selectedGenre" placeholder="选择类型" clearable>
        <el-option
          v-for="genre in genres"
          :key="genre.id"
          :label="genre.name"
          :value="genre.id"
        />
      </el-select>

      <el-slider
        v-model="ratingRange"
        range
        :min="0"
        :max="5"
        :step="0.5"
        show-stops
        style="width: 300px; margin-left: 20px;"
      >
        <template #prefix>评分范围:</template>
      </el-slider>
    </div>

    <div class="search-results">
      <div v-if="loading" class="loading-container">
        <LoadingSpinner />
      </div>

      <div v-else-if="error" class="error-container">
        <ErrorMessage :message="error" @retry="searchMovies" />
      </div>

      <div v-else>
        <div v-if="movies.length === 0" class="empty-state">
          <EmptyState
            message="没有找到匹配的电影"
            action-text="返回电影列表"
            @action="$router.push('/movies')"
          />
        </div>

        <div v-else class="movie-grid">
          <MovieCard
            v-for="movie in filteredMovies"
            :key="movie.id"
            :movie="movie"
            @click="viewMovieDetail(movie.id)"
          />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useMovieStore } from '@/store/movies'
import MovieCard from '@/components/movie/MovieCard.vue'
import LoadingSpinner from '@/components/common/LoadingSpinner.vue'
import ErrorMessage from '@/components/common/ErrorMessage.vue'
import EmptyState from '@/components/common/EmptyState.vue'

const route = useRoute()
const router = useRouter()
const movieStore = useMovieStore()

const searchQuery = ref(route.query.q || '')
const selectedGenre = ref('')
const ratingRange = ref([0, 5])
const loading = ref(false)
const error = ref(null)

const movies = computed(() => movieStore.movies)
const genres = computed(() => movieStore.genres)

const filteredMovies = computed(() => {
  return movies.value.filter(movie => {
    // 匹配搜索词
    const matchesSearch = searchQuery.value ?
      movie.title.toLowerCase().includes(searchQuery.value.toLowerCase()) : true

    // 匹配类型
    const matchesGenre = selectedGenre.value ?
      movie.genres.some(g => g.id === selectedGenre.value) : true

    // 匹配评分范围
    const matchesRating = movie.avg_rating >= ratingRange.value[0] &&
                         movie.avg_rating <= ratingRange.value[1]

    return matchesSearch && matchesGenre && matchesRating
  })
})

const searchMovies = async () => {
  if (!searchQuery.value.trim()) return

  loading.value = true
  error.value = null

  try {
    await movieStore.searchMovies(searchQuery.value)
    // 更新URL
    router.push({
      path: '/search',
      query: { q: searchQuery.value }
    })
  } catch (err) {
    error.value = '搜索失败，请稍后再试'
    console.error(err)
  } finally {
    loading.value = false
  }
}

const viewMovieDetail = (movieId) => {
  router.push({ name: 'movie-detail', params: { id: movieId } })
}

onMounted(async () => {
  // 加载类型数据
  await movieStore.fetchGenres()

  // 如果有搜索参数，执行搜索
  if (searchQuery.value) {
    await searchMovies()
  }
})
</script>

<style scoped>
.search-view {
  max-width: 1200px;
  margin: 30px auto;
  padding: 0 20px;
}

.search-header {
  margin-bottom: 20px;
}

.search-filters {
  display: flex;
  align-items: center;
  margin-bottom: 30px;
  flex-wrap: wrap;
  gap: 15px;
}

.movie-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
  gap: 25px;
}

.loading-container,
.error-container,
.empty-state {
  min-height: 300px;
  display: flex;
  align-items: center;
  justify-content: center;
}

@media (max-width: 768px) {
  .search-filters {
    flex-direction: column;
    align-items: flex-start;
  }
}
</style>