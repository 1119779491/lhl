<template>
  <div class="home-view">
    <section class="hero-section">
      <div class="hero-content">
        <h1>发现你的下一部最爱电影</h1>
        <p>基于您的个人品味和观影历史精心推荐</p>
        <el-button type="primary" size="large" @click="goToRecommendations">
          获取推荐
        </el-button>
      </div>
    </section>

    <section class="featured-section">
      <h2>热门电影</h2>
      <div v-if="popularMovies.length > 0" class="movie-grid">
        <MovieCard
          v-for="movie in popularMovies"
          :key="movie.id"
          :movie="movie"
          @click="viewMovieDetail(movie.id)"
        />
      </div>
      <LoadingSpinner v-else />
    </section>

    <section class="genres-section">
      <h2>按类型浏览</h2>
      <div class="genres-grid">
        <el-card
          v-for="genre in genres"
          :key="genre.id"
          class="genre-card"
          @click="filterByGenre(genre.id)"
        >
          <div class="genre-content">
            <h3>{{ genre.name }}</h3>
            <p>探索更多</p>
          </div>
        </el-card>
      </div>
    </section>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useMovieStore } from '@/store/movies'
import MovieCard from '@/components/movie/MovieCard.vue'
import LoadingSpinner from '@/components/common/LoadingSpinner.vue'

const movieStore = useMovieStore()
const router = useRouter()

const popularMovies = ref([])
const genres = ref([])

const goToRecommendations = () => {
  router.push({ name: 'recommendations' })
}

const viewMovieDetail = (movieId) => {
  router.push({ name: 'movie-detail', params: { id: movieId } })
}

const filterByGenre = (genreId) => {
  router.push({
    name: 'movies',
    query: { genre: genreId }
  })
}

onMounted(async () => {
  await movieStore.fetchMovies()
  await movieStore.fetchGenres()

  // 获取热门电影（按评分排序）
  popularMovies.value = [...movieStore.movies]
    .sort((a, b) => b.avg_rating - a.avg_rating)
    .slice(0, 8)

  genres.value = movieStore.genres.slice(0, 8)
})
</script>

<style scoped>
.home-view {
  max-width: 1400px;
  margin: 0 auto;
}

.hero-section {
  background: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)),
              url('https://source.unsplash.com/random/1600x900/?movie,theater') center/cover;
  height: 500px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  text-align: center;
  margin-bottom: 50px;
  border-radius: 0 0 20px 20px;
}

.hero-content {
  max-width: 800px;
  padding: 20px;
}

.hero-content h1 {
  font-size: 48px;
  margin-bottom: 20px;
}

.hero-content p {
  font-size: 24px;
  margin-bottom: 30px;
}

.featured-section,
.genres-section {
  margin-bottom: 60px;
  padding: 0 20px;
}

h2 {
  font-size: 28px;
  margin-bottom: 30px;
  text-align: center;
}

.movie-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
  gap: 25px;
}

.genres-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 20px;
}

.genre-card {
  cursor: pointer;
  transition: transform 0.3s ease;
}

.genre-card:hover {
  transform: translateY(-5px);
}

.genre-content {
  padding: 20px;
  text-align: center;
}

.genre-content h3 {
  margin-bottom: 10px;
}

.genre-content p {
  color: #409EFF;
  font-size: 14px;
}

@media (max-width: 768px) {
  .hero-section {
    height: 400px;
  }

  .hero-content h1 {
    font-size: 36px;
  }

  .hero-content p {
    font-size: 18px;
  }
}
</style>