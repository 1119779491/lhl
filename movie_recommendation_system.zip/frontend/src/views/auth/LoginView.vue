<template>
  <div class="login-container">
    <el-card class="login-card">
      <h2>欢迎登录</h2>
      <el-form
        :model="loginForm"
        :rules="rules"
        ref="loginFormRef"
        @keyup.enter.native="submitForm" <!-- 添加回车键提交 -->
      >
        <el-form-item prop="email">
          <!-- 修复输入框：使用原生input事件 -->
          <el-input
            v-model="loginForm.email"
            placeholder="邮箱"
            prefix-icon="el-icon-message"
            @input="handleEmailInput" <!-- 添加输入事件处理 -->
          />
        </el-form-item>
        <el-form-item prop="password">
          <el-input
            v-model="loginForm.password"
            placeholder="密码"
            type="password"
            show-password
            prefix-icon="el-icon-lock"
            @input="handlePasswordInput" <!-- 添加输入事件处理 -->
          />
        </el-form-item>
        <el-form-item>
          <el-button
            type="primary"
            @click="submitForm"
            :loading="loading"
            style="width: 100%;" <!-- 全宽按钮 -->
          >
            登录
          </el-button>
        </el-form-item>
      </el-form>
      <div class="login-footer">
        <p>还没有账号？<router-link to="/register">立即注册</router-link></p>
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { ref, nextTick } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/store/auth'
import { ElMessage } from 'element-plus'

const authStore = useAuthStore()
const router = useRouter()
const loginFormRef = ref(null)

// 使用 reactive 代替 ref 确保深度响应式
const loginForm = ref({
  email: '',
  password: ''
})

const loading = ref(false)

const rules = {
  email: [
    { required: true, message: '请输入邮箱地址', trigger: 'blur' },
    {
      type: 'email',
      message: '请输入正确的邮箱地址',
      trigger: ['blur', 'change']
    }
  ],
  password: [
    { required: true, message: '请输入密码', trigger: 'blur' },
    { min: 6, message: '密码长度不能少于6位', trigger: 'blur' }
  ]
}

// 修复输入框问题的关键方法
const handleEmailInput = (value) => {
  // 强制更新视图
  nextTick(() => {
    loginForm.value.email = value
  })
}

const handlePasswordInput = (value) => {
  // 强制更新视图
  nextTick(() => {
    loginForm.value.password = value
  })
}

const submitForm = async () => {
  // 验证表单
  if (!loginFormRef.value) return

  try {
    await loginFormRef.value.validate()
  } catch (error) {
    ElMessage.warning('请填写正确的登录信息')
    return
  }

  loading.value = true

  try {
    // 使用 await 确保登录完成
    await authStore.login({
      email: loginForm.value.email,
      password: loginForm.value.password
    })

    if (authStore.isAuthenticated) {
      ElMessage.success('登录成功')
      router.push('/')
    } else {
      ElMessage.error('登录失败，请检查您的凭据')
    }
  } catch (error) {
    // 显示详细错误信息
    const errorDetail = error.response?.data?.detail ||
                        error.response?.data?.error ||
                        '登录过程中发生错误'

    ElMessage.error(`登录失败: ${errorDetail}`)
    console.error('登录错误详情:', error.response)
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.login-container {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  background-color: #f5f7fa;
  padding: 20px;
}

.login-card {
  width: 100%;
  max-width: 400px;
  padding: 25px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.login-footer {
  margin-top: 20px;
  text-align: center;
  color: #606266;
  font-size: 14px;
}

/* 修复输入框样式问题 */
:deep(.el-input__inner) {
  padding: 12px 15px;
  font-size: 16px;
}

:deep(.el-form-item) {
  margin-bottom: 22px;
}

:deep(.el-button) {
  padding: 12px 20px;
  font-size: 16px;
}
</style>