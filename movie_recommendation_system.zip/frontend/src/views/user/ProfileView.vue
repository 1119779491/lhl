<template>
  <div class="profile-view">
    <el-card class="profile-card">
      <div class="profile-header">
        <el-avatar :src="user.avatar_url || defaultAvatar" :size="120" />
        <div class="profile-info">
          <h1>{{ user.username }}</h1>
          <p>{{ user.email }}</p>
          <p v-if="user.bio">{{ user.bio }}</p>
          <p>加入日期: {{ formatDate(user.date_joined) }}</p>
        </div>
      </div>

      <el-tabs v-model="activeTab" class="profile-tabs">
        <el-tab-pane label="个人信息" name="info">
          <el-form :model="userForm" label-width="100px">
            <el-form-item label="用户名">
              <el-input v-model="userForm.username" />
            </el-form-item>
            <el-form-item label="头像">
              <el-upload
                class="avatar-uploader"
                action="/api/upload/"
                :show-file-list="false"
                :on-success="handleAvatarSuccess"
              >
                <img v-if="userForm.avatar_url" :src="userForm.avatar_url" class="avatar" />
                <el-icon v-else class="avatar-uploader-icon"><Plus /></el-icon>
              </el-upload>
            </el-form-item>
            <el-form-item label="个人简介">
              <el-input v-model="userForm.bio" type="textarea" :rows="3" />
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="updateProfile">保存更改</el-button>
            </el-form-item>
          </el-form>
        </el-tab-pane>

        <el-tab-pane label="观影历史" name="history">
          <div v-if="historyLoading" class="loading-container">
            <LoadingSpinner />
          </div>
          <div v-else-if="viewHistory.length === 0" class="empty-state">
            <EmptyState message="暂无观影历史" />
          </div>
          <div v-else class="history-list">
            <div v-for="item in viewHistory" :key="item.id" class="history-item">
              <el-card shadow="hover" @click="viewMovieDetail(item.movie.id)">
                <div class="history-content">
                  <img :src="item.movie.poster_url" class="history-poster" />
                  <div class="history-info">
                    <h3>{{ item.movie.title }}</h3>
                    <p>观看时间: {{ formatDateTime(item.viewed_at) }}</p>
                    <p>导演: {{ item.movie.director }}</p>
                  </div>
                </div>
              </el-card>
            </div>
          </div>
        </el-tab-pane>

        <el-tab-pane label="我的评分" name="ratings">
          <div v-if="ratingsLoading" class="loading-container">
            <LoadingSpinner />
          </div>
          <div v-else-if="userRatings.length === 0" class="empty-state">
            <EmptyState message="暂无评分记录" />
          </div>
          <div v-else class="ratings-list">
            <div v-for="rating in userRatings" :key="rating.id" class="rating-item">
              <el-card shadow="hover" @click="viewMovieDetail(rating.movie.id)">
                <div class="rating-content">
                  <img :src="rating.movie.poster_url" class="rating-poster" />
                  <div class="rating-info">
                    <h3>{{ rating.movie.title }}</h3>
                    <div class="rating-value">
                      <el-rate
                        v-model="rating.rating_value"
                        disabled
                        :max="5"
                        allow-half
                        :show-score="true"
                        score-template="{value}"
                      />
                      <span class="rating-date">{{ formatDate(rating.created_at) }}</span>
                    </div>
                  </div>
                </div>
              </el-card>
            </div>
          </div>
        </el-tab-pane>
      </el-tabs>
    </el-card>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted, computed } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/store/auth'
import { getUserHistory, getUserRatings } from '@/api/interactions'
import { updateUserProfile } from '@/api/auth'
import { formatDate, formatDateTime } from '@/utils/helpers'
import { ElMessage } from 'element-plus'
import { Plus } from '@element-plus/icons-vue'
import LoadingSpinner from '@/components/common/LoadingSpinner.vue'
import EmptyState from '@/components/common/EmptyState.vue'

const authStore = useAuthStore()
const router = useRouter()

const activeTab = ref('info')
const viewHistory = ref([])
const userRatings = ref([])
const historyLoading = ref(false)
const ratingsLoading = ref(false)
const defaultAvatar = 'https://via.placeholder.com/120?text=Avatar'

// 用户表单数据
const userForm = reactive({
  username: '',
  avatar_url: '',
  bio: ''
})

// 计算用户数据
const user = computed(() => authStore.user)

// 初始化表单数据
const initForm = () => {
  if (user.value) {
    userForm.username = user.value.username
    userForm.avatar_url = user.value.avatar_url
    userForm.bio = user.value.bio || ''
  }
}

// 加载用户历史
const loadViewHistory = async () => {
  historyLoading.value = true
  try {
    const response = await getUserHistory()
    viewHistory.value = response.data
  } catch (error) {
    ElMessage.error('加载观影历史失败')
    console.error(error)
  } finally {
    historyLoading.value = false
  }
}

// 加载用户评分
const loadUserRatings = async () => {
  ratingsLoading.value = true
  try {
    const response = await getUserRatings()
    userRatings.value = response.data.map(rating => ({
      ...rating,
      rating_value: rating.rating_value / 2 // 转换为5分制
    }))
  } catch (error) {
    ElMessage.error('加载评分记录失败')
    console.error(error)
  } finally {
    ratingsLoading.value = false
  }
}

// 更新个人资料
const updateProfile = async () => {
  try {
    const response = await updateUserProfile(userForm)
    authStore.user = { ...authStore.user, ...response.data }
    ElMessage.success('个人资料已更新')
  } catch (error) {
    ElMessage.error('更新个人资料失败')
    console.error(error)
  }
}

// 头像上传成功
const handleAvatarSuccess = (response) => {
  if (response.url) {
    userForm.avatar_url = response.url
    ElMessage.success('头像上传成功')
  }
}

// 查看电影详情
const viewMovieDetail = (movieId) => {
  router.push({ name: 'movie-detail', params: { id: movieId } })
}

onMounted(() => {
  initForm()
  loadViewHistory()
  loadUserRatings()
})
</script>

<style scoped>
.profile-view {
  max-width: 1200px;
  margin: 30px auto;
  padding: 0 20px;
}

.profile-card {
  padding: 30px;
}

.profile-header {
  display: flex;
  align-items: center;
  margin-bottom: 30px;
  padding-bottom: 30px;
  border-bottom: 1px solid #eee;
}

.profile-info {
  margin-left: 30px;
}

.profile-info h1 {
  font-size: 28px;
  margin-bottom: 10px;
}

.profile-info p {
  color: #606266;
  margin-bottom: 8px;
}

.profile-tabs {
  margin-top: 20px;
}

.history-item,
.rating-item {
  margin-bottom: 20px;
}

.history-content,
.rating-content {
  display: flex;
}

.history-poster,
.rating-poster {
  width: 80px;
  height: 120px;
  object-fit: cover;
  margin-right: 20px;
  border-radius: 4px;
}

.history-info,
.rating-info {
  flex: 1;
}

.rating-value {
  display: flex;
  align-items: center;
  margin-top: 10px;
}

.rating-date {
  margin-left: 15px;
  color: #909399;
  font-size: 14px;
}

.avatar-uploader {
  display: inline-block;
}

.avatar-uploader .avatar {
  width: 120px;
  height: 120px;
  display: block;
  border-radius: 50%;
  object-fit: cover;
}

.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 120px;
  height: 120px;
  text-align: center;
  border: 1px dashed #d9d9d9;
  border-radius: 50%;
  cursor: pointer;
  transition: border-color 0.3s;
  display: flex;
  align-items: center;
  justify-content: center;
}

.avatar-uploader-icon:hover {
  border-color: #409eff;
}

.loading-container,
.empty-state {
  min-height: 300px;
  display: flex;
  align-items: center;
  justify-content: center;
}

@media (max-width: 768px) {
  .profile-header {
    flex-direction: column;
    text-align: center;
  }

  .profile-info {
    margin-left: 0;
    margin-top: 20px;
  }

  .history-content,
  .rating-content {
    flex-direction: column;
  }

  .history-poster,
  .rating-poster {
    margin-right: 0;
    margin-bottom: 15px;
    width: 100%;
    height: auto;
    max-height: 300px;
  }
}
</style>