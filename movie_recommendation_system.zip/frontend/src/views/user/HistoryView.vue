<template>
  <div class="history-view">
    <el-card class="history-card">
      <h2>观影历史</h2>

      <div v-if="loading" class="loading-container">
        <LoadingSpinner />
      </div>

      <div v-else-if="error" class="error-container">
        <ErrorMessage :message="error" />
      </div>

      <div v-else>
        <div v-if="viewHistory.length === 0" class="empty-state">
          <EmptyState message="暂无观影历史" />
        </div>

        <div v-else class="history-list">
          <div v-for="item in viewHistory" :key="item.id" class="history-item">
            <el-card shadow="hover" @click="viewMovieDetail(item.movie.id)">
              <div class="history-content">
                <img :src="item.movie.poster_url" class="history-poster" />
                <div class="history-info">
                  <h3>{{ item.movie.title }}</h3>
                  <p>观看时间: {{ formatDateTime(item.viewed_at) }}</p>
                  <p>导演: {{ item.movie.director }}</p>
                  <p>时长: {{ formatDuration(item.movie.duration) }}</p>
                  <div class="movie-rating">
                    <el-rate
                      v-model="item.movie.avg_rating"
                      disabled
                      :max="5"
                      allow-half
                      :show-score="true"
                      score-template="{value}"
                    />
                  </div>
                </div>
              </div>
            </el-card>
          </div>
        </div>

        <div class="pagination-container">
          <el-pagination
            v-model:current-page="currentPage"
            :page-size="pageSize"
            layout="prev, pager, next"
            :total="viewHistory.length"
            @current-change="handlePageChange"
          />
        </div>
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { getUserHistory } from '@/api/interactions'
import { formatDateTime, formatDuration } from '@/utils/helpers'
import { ElMessage } from 'element-plus'
import LoadingSpinner from '@/components/common/LoadingSpinner.vue'
import ErrorMessage from '@/components/common/ErrorMessage.vue'
import EmptyState from '@/components/common/EmptyState.vue'

const router = useRouter()
const viewHistory = ref([])
const loading = ref(true)
const error = ref(null)
const currentPage = ref(1)
const pageSize = ref(10)

const paginatedHistory = computed(() => {
  const start = (currentPage.value - 1) * pageSize.value
  return viewHistory.value.slice(start, start + pageSize.value)
})

const loadViewHistory = async () => {
  loading.value = true
  try {
    const response = await getUserHistory()
    viewHistory.value = response.data
    error.value = null
  } catch (err) {
    error.value = '加载观影历史失败'
    ElMessage.error('加载观影历史失败')
    console.error(err)
  } finally {
    loading.value = false
  }
}

const viewMovieDetail = (movieId) => {
  router.push({ name: 'movie-detail', params: { id: movieId } })
}

const handlePageChange = (page) => {
  currentPage.value = page
  window.scrollTo({ top: 0, behavior: 'smooth' })
}

onMounted(() => {
  loadViewHistory()
})
</script>

<style scoped>
.history-view {
  max-width: 1200px;
  margin: 30px auto;
  padding: 0 20px;
}

.history-card {
  padding: 30px;
}

.history-list {
  margin-top: 20px;
}

.history-item {
  margin-bottom: 20px;
}

.history-content {
  display: flex;
  padding: 15px;
}

.history-poster {
  width: 100px;
  height: 150px;
  object-fit: cover;
  border-radius: 4px;
  margin-right: 20px;
}

.history-info {
  flex: 1;
}

.history-info h3 {
  font-size: 18px;
  margin-bottom: 10px;
}

.history-info p {
  color: #606266;
  margin-bottom: 8px;
  font-size: 14px;
}

.movie-rating {
  margin-top: 10px;
}

:deep(.el-rate) {
  display: inline-flex;
}

:deep(.el-rate__text) {
  margin-left: 10px;
  font-weight: bold;
  color: #f56c6c;
}

.loading-container,
.error-container,
.empty-state {
  min-height: 300px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.pagination-container {
  display: flex;
  justify-content: center;
  margin-top: 30px;
}

@media (max-width: 768px) {
  .history-content {
    flex-direction: column;
  }

  .history-poster {
    width: 100%;
    height: auto;
    max-height: 300px;
    margin-right: 0;
    margin-bottom: 15px;
  }
}
</style>