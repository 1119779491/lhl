<template>
  <el-card class="movie-detail-card">
    <div class="movie-header">
      <img :src="movie.poster_url" :alt="movie.title" class="poster" />
      <div class="movie-info">
        <h2>{{ movie.title }}</h2>
        <p>{{ movie.release_year }} | {{ formatDuration(movie.duration) }}</p>
        <p>导演: {{ movie.director }}</p>
        <div class="movie-genres">
          <el-tag
            v-for="genre in movie.genres"
            :key="genre.id"
            size="small"
            class="genre-tag"
          >
            {{ genre.name }}
          </el-tag>
        </div>
        <div class="movie-rating">
          <el-rate
            v-model="movie.avg_rating"
            disabled
            :max="5"
            allow-half
            :show-score="true"
            score-template="{value}"
          />
          <span>({{ movie.ratings_count }}人评分)</span>
        </div>
      </div>
    </div>
    <div class="movie-description">
      <h3>剧情简介</h3>
      <p>{{ movie.description }}</p>
    </div>
  </el-card>
</template>

<script setup>
import { formatDuration } from '@/utils/helpers'

defineProps({
  movie: {
    type: Object,
    required: true
  }
})
</script>

<style scoped>
.movie-detail-card {
  margin-bottom: 20px;
}

.movie-header {
  display: flex;
  margin-bottom: 20px;
}

.poster {
  width: 200px;
  height: 300px;
  object-fit: cover;
  border-radius: 4px;
  margin-right: 20px;
}

.movie-info h2 {
  margin-bottom: 10px;
}

.movie-genres {
  display: flex;
  flex-wrap: wrap;
  gap: 5px;
  margin: 10px 0;
}

.genre-tag {
  margin-right: 5px;
}

.movie-rating {
  display: flex;
  align-items: center;
}

.movie-rating span {
  margin-left: 10px;
  color: #909399;
  font-size: 14px;
}

.movie-description h3 {
  margin-bottom: 10px;
}

.movie-description p {
  line-height: 1.6;
  color: #606266;
}

@media (max-width: 768px) {
  .movie-header {
    flex-direction: column;
  }

  .poster {
    width: 100%;
    height: auto;
    max-height: 400px;
    margin-right: 0;
    margin-bottom: 15px;
  }
}
</style>