<template>
  <div class="rating-component">
    <h3>我的评分</h3>
    <el-rate
      v-model="ratingValue"
      :max="5"
      allow-half
      @change="submitRating"
      :disabled="disabled"
    />
    <span v-if="ratingValue > 0" class="rating-text">已评分: {{ ratingValue }}</span>
    <span v-else class="rating-text">未评分</span>
  </div>
</template>

<script setup>
import { ref, watch } from 'vue'
import { addRating } from '@/api/interactions'
import { ElMessage } from 'element-plus'

const props = defineProps({
  movieId: {
    type: String,
    required: true
  },
  userRating: {
    type: Number,
    default: 0
  },
  disabled: {
    type: Boolean,
    default: false
  }
})

const emit = defineEmits(['rated'])

const ratingValue = ref(props.userRating)

watch(() => props.userRating, (newVal) => {
  ratingValue.value = newVal
})

const submitRating = async (value) => {
  try {
    await addRating({
      movie: props.movieId,
      rating_value: value * 2  // 转换为10分制
    })
    ElMessage.success('评分成功')
    emit('rated', value)
  } catch (error) {
    ElMessage.error('评分失败')
    console.error(error)
  }
}
</script>

<style scoped>
.rating-component {
  margin: 20px 0;
}

.rating-text {
  margin-left: 15px;
  font-size: 14px;
  color: #606266;
}
</style>