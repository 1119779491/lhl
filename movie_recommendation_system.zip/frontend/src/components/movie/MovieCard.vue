<template>
  <el-card class="movie-card" shadow="hover" @click="$emit('click')">
    <div class="movie-poster-container">
      <img
        :src="movie.poster_url"
        :alt="movie.title"
        class="movie-poster"
        @error="handleImageError"
      />
      <div class="movie-rating">
        <el-rate
          v-model="movie.avg_rating"
          disabled
          :max="5"
          allow-half
          :show-score="true"
          score-template="{value}"
        />
      </div>
    </div>

    <div class="movie-info">
      <h3 class="movie-title">{{ movie.title }}</h3>
      <div class="movie-meta">
        <span>{{ movie.release_year }}</span>
        <span> · </span>
        <span>{{ formatDuration(movie.duration) }}</span>
      </div>
      <div class="movie-genres">
        <el-tag
          v-for="genre in movie.genres.slice(0, 2)"
          :key="genre.id"
          size="small"
          class="genre-tag"
        >
          {{ genre.name }}
        </el-tag>
        <span v-if="movie.genres.length > 2" class="more-tags">+{{ movie.genres.length - 2 }}</span>
      </div>
    </div>
  </el-card>
</template>

<script setup>
import { defineProps } from 'vue'

const props = defineProps({
  movie: {
    type: Object,
    required: true
  }
})

const handleImageError = (e) => {
  e.target.src = 'https://via.placeholder.com/300x450?text=No+Image'
}

const formatDuration = (minutes) => {
  const hours = Math.floor(minutes / 60)
  const mins = minutes % 60
  return `${hours ? `${hours}h ` : ''}${mins}m`
}
</script>

<style scoped>
.movie-card {
  cursor: pointer;
  height: 100%;
  transition: transform 0.3s ease;
}

.movie-card:hover {
  transform: translateY(-5px);
}

.movie-poster-container {
  position: relative;
  overflow: hidden;
  border-radius: 4px;
  padding-top: 150%; /* 2:3 aspect ratio */
}

.movie-poster {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.3s ease;
}

.movie-card:hover .movie-poster {
  transform: scale(1.05);
}

.movie-rating {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  background: linear-gradient(transparent, rgba(0, 0, 0, 0.7));
  padding: 10px;
}

:deep(.el-rate) {
  display: flex;
  justify-content: center;
}

:deep(.el-rate__icon) {
  font-size: 14px;
}

:deep(.el-rate__text) {
  margin-left: 5px;
  font-size: 14px;
  color: #fff;
  font-weight: bold;
}

.movie-info {
  padding: 15px 10px 10px;
}

.movie-title {
  font-size: 16px;
  margin: 0 0 8px;
  line-height: 1.3;
  height: 42px;
  overflow: hidden;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}

.movie-meta {
  display: flex;
  align-items: center;
  color: #909399;
  font-size: 13px;
  margin-bottom: 10px;
}

.movie-genres {
  display: flex;
  flex-wrap: wrap;
  gap: 5px;
}

.genre-tag {
  margin-right: 5px;
}

.more-tags {
  font-size: 12px;
  color: #909399;
}
</style>