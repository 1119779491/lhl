<template>
  <div class="review-list">
    <h3>用户评论 ({{ reviews.length }})</h3>

    <div v-if="reviews.length === 0" class="empty-reviews">
      <p>暂无评论，成为第一个评论者吧！</p>
    </div>

    <div v-else>
      <div v-for="review in reviews" :key="review.id" class="review-item">
        <div class="review-header">
          <el-avatar :src="review.user.avatar_url || defaultAvatar" :size="40" />
          <div class="review-user">
            <span class="username">{{ review.user.username }}</span>
            <span class="date">{{ formatDate(review.created_at) }}</span>
          </div>
        </div>
        <div class="review-content">
          <p>{{ review.content }}</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { formatDate } from '@/utils/helpers'

defineProps({
  reviews: {
    type: Array,
    default: () => []
  }
})

const defaultAvatar = 'https://via.placeholder.com/40'
</script>

<style scoped>
.review-list {
  margin-top: 30px;
  padding: 20px;
  background-color: #f8f9fa;
  border-radius: 8px;
}

.review-item {
  padding: 15px 0;
  border-bottom: 1px solid #eee;
}

.review-item:last-child {
  border-bottom: none;
}

.review-header {
  display: flex;
  align-items: center;
  margin-bottom: 10px;
}

.review-user {
  margin-left: 15px;
}

.username {
  font-weight: bold;
  display: block;
}

.date {
  font-size: 12px;
  color: #909399;
}

.review-content p {
  line-height: 1.5;
  color: #606266;
}

.empty-reviews {
  text-align: center;
  padding: 20px;
  color: #909399;
}
</style>