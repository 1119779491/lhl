<template>
  <el-menu
    mode="horizontal"
    :router="true"
    class="navbar"
    :class="{ 'scrolled': scrolled }"
  >
    <div class="navbar-container">
      <router-link to="/" class="logo">
        <img src="@/assets/logo.png" alt="MovieRec" />
        <span>MovieRec</span>
      </router-link>

      <div class="nav-links">
        <el-menu-item index="/">首页</el-menu-item>
        <el-menu-item index="/movies">电影库</el-menu-item>
        <el-menu-item index="/recommendations">推荐</el-menu-item>
      </div>

      <div class="nav-right">
        <el-input
          v-model="searchQuery"
          placeholder="搜索电影..."
          class="search-input"
          @keyup.enter="searchMovies"
        />
        <el-dropdown v-if="isAuthenticated">
          <span class="user-dropdown">
            <img :src="user.avatar_url || defaultAvatar" class="avatar" />
            <span>{{ user.username }}</span>
          </span>
          <template #dropdown>
            <el-dropdown-menu>
              <el-dropdown-item @click="goToProfile">个人中心</el-dropdown-item>
              <el-dropdown-item @click="logout">退出登录</el-dropdown-item>
            </el-dropdown-menu>
          </template>
        </el-dropdown>
        <div v-else class="auth-buttons">
          <el-button type="text" @click="goToLogin">登录</el-button>
          <el-button type="primary" @click="goToRegister">注册</el-button>
        </div>
      </div>
    </div>
  </el-menu>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/store/auth'

const authStore = useAuthStore()
const router = useRouter()
const searchQuery = ref('')
const scrolled = ref(false)

const user = computed(() => authStore.user)
const isAuthenticated = computed(() => authStore.isAuthenticated)
const defaultAvatar = 'https://via.placeholder.com/40'

const searchMovies = () => {
  if (searchQuery.value.trim()) {
    router.push({ name: 'movies', query: { search: searchQuery.value } })
    searchQuery.value = ''
  }
}

const goToProfile = () => {
  router.push({ name: 'profile' })
}

const logout = () => {
  authStore.logout()
  router.push('/login')
}

const goToLogin = () => {
  router.push('/login')
}

const goToRegister = () => {
  router.push('/register')
}

// 滚动监听
window.addEventListener('scroll', () => {
  scrolled.value = window.scrollY > 20
})
</script>

<style scoped>
.navbar {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 1000;
  background: transparent;
  transition: background-color 0.3s, box-shadow 0.3s;
}

.navbar.scrolled {
  background: rgba(255, 255, 255, 0.95);
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.navbar-container {
  display: flex;
  align-items: center;
  max-width: 1400px;
  margin: 0 auto;
  padding: 0 20px;
  height: 60px;
}

.logo {
  display: flex;
  align-items: center;
  margin-right: 30px;
  text-decoration: none;
}

.logo img {
  height: 40px;
  margin-right: 10px;
}

.logo span {
  font-size: 20px;
  font-weight: bold;
  color: #409EFF;
}

.nav-links {
  flex: 1;
}

.nav-right {
  display: flex;
  align-items: center;
  gap: 20px;
}

.search-input {
  width: 250px;
}

.user-dropdown {
  display: flex;
  align-items: center;
  cursor: pointer;
}

.avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  object-fit: cover;
  margin-right: 10px;
}

.auth-buttons {
  display: flex;
  gap: 10px;
}
</style>