<template>
  <footer class="app-footer">
    <div class="footer-container">
      <div class="footer-section">
        <h3>关于我们</h3>
        <p>MovieRec 是一个智能电影推荐系统，帮助您发现更多喜爱的电影。</p>
      </div>

      <div class="footer-section">
        <h3>快速链接</h3>
        <ul>
          <li><router-link to="/">首页</router-link></li>
          <li><router-link to="/movies">电影库</router-link></li>
          <li><router-link to="/recommendations">推荐系统</router-link></li>
        </ul>
      </div>

      <div class="footer-section">
        <h3>联系方式</h3>
        <p>邮箱: contact@movierec.com</p>
        <p>电话: 123-456-7890</p>
      </div>
    </div>

    <div class="copyright">
      &copy; 2023 MovieRec 电影推荐系统. 保留所有权利.
    </div>
  </footer>
</template>

<style scoped>
.app-footer {
  background-color: #2c3e50;
  color: #ecf0f1;
  padding: 40px 0 20px;
}

.footer-container {
  display: flex;
  justify-content: space-around;
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
}

.footer-section {
  flex: 1;
  margin: 0 15px;
}

.footer-section h3 {
  font-size: 18px;
  margin-bottom: 20px;
  position: relative;
  padding-bottom: 10px;
}

.footer-section h3::after {
  content: '';
  position: absolute;
  bottom: 0;
  left: 0;
  width: 50px;
  height: 2px;
  background-color: #409EFF;
}

.footer-section p {
  line-height: 1.6;
  margin-bottom: 10px;
}

.footer-section ul {
  list-style: none;
  padding: 0;
}

.footer-section ul li {
  margin-bottom: 10px;
}

.footer-section ul li a {
  color: #bdc3c7;
  text-decoration: none;
  transition: color 0.3s;
}

.footer-section ul li a:hover {
  color: #409EFF;
}

.copyright {
  text-align: center;
  margin-top: 40px;
  padding-top: 20px;
  border-top: 1px solid rgba(255, 255, 255, 0.1);
  color: #95a5a6;
  font-size: 14px;
}

@media (max-width: 768px) {
  .footer-container {
    flex-direction: column;
  }

  .footer-section {
    margin-bottom: 30px;
  }
}
</style>