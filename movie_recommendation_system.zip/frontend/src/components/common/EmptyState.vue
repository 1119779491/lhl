<template>
  <div class="empty-state">
    <img :src="imageUrl" class="empty-image" />
    <h3 class="empty-title">{{ title }}</h3>
    <p class="empty-message">{{ message }}</p>
    <el-button
      v-if="actionText"
      type="primary"
      @click="$emit('action')"
      class="action-button"
    >
      {{ actionText }}
    </el-button>
  </div>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  title: {
    type: String,
    default: '暂无数据'
  },
  message: {
    type: String,
    default: '当前没有可显示的内容'
  },
  actionText: String
})

const imageUrl = computed(() => {
  return 'https://via.placeholder.com/300x200?text=No+Data'
})
</script>

<style scoped>
.empty-state {
  text-align: center;
  padding: 40px 20px;
}

.empty-image {
  max-width: 300px;
  margin-bottom: 20px;
  opacity: 0.6;
}

.empty-title {
  font-size: 20px;
  margin-bottom: 10px;
  color: #606266;
}

.empty-message {
  font-size: 14px;
  color: #909399;
  margin-bottom: 20px;
}

.action-button {
  margin-top: 15px;
}
</style>