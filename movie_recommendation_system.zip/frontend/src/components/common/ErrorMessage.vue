<template>
  <div class="error-message">
    <el-alert :title="title" type="error" :closable="false">
      <p>{{ message }}</p>
      <el-button v-if="showRetry" type="primary" @click="handleRetry" class="retry-button">重试</el-button>
    </el-alert>
  </div>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  message: {
    type: String,
    default: '发生错误，请稍后再试'
  },
  title: {
    type: String,
    default: '错误'
  },
  showRetry: {
    type: Boolean,
    default: true
  }
})

const emit = defineEmits(['retry'])

const handleRetry = () => {
  emit('retry')
}
</script>

<style scoped>
.error-message {
  margin: 20px 0;
}

.retry-button {
  margin-top: 15px;
}
</style>