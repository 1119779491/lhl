<template>
  <div class="app-container">
    <NavBar />
    <router-view class="router-view" />
    <Footer />
  </div>
</template>

<script setup>
import NavBar from '@/components/layout/NavBar.vue'
import Footer from '@/components/layout/Footer.vue'
import { useAuthStore } from '@/store/auth'

const authStore = useAuthStore()

// 初始化时获取用户信息
if (authStore.isAuthenticated) {
  authStore.fetchProfile()
}
</script>

<style>
.app-container {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
}

.router-view {
  flex: 1;
  padding-top: 80px; /* 给导航栏留出空间 */
  padding-bottom: 40px;
}

/* 全局样式重置 */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
  line-height: 1.6;
  color: #333;
  background-color: #f5f7fa;
}

a {
  text-decoration: none;
  color: inherit;
}

/* Element Plus 组件样式覆盖 */
.el-button {
  transition: all 0.3s ease;
}

.el-card {
  border-radius: 8px;
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.el-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
}

.el-pagination {
  margin-top: 20px;
}

/* 响应式调整 */
@media (max-width: 768px) {
  .router-view {
    padding-top: 70px;
    padding-left: 10px;
    padding-right: 10px;
  }
}
</style>