import { defineStore } from 'pinia'
import { login, register, getProfile } from '@/api/auth'

export const useAuthStore = defineStore('auth', {
  state: () => ({
    user: null,
    token: localStorage.getItem('token') || null,
    isAuthenticated: !!localStorage.getItem('token')
  }),
  actions: {
    async login(credentials) {
      try {
        const response = await login(credentials)
        this.token = response.data.token
        this.user = response.data.user
        this.isAuthenticated = true
        localStorage.setItem('token', response.data.token)
        this.error = null
        return true
      } catch (error) {
        this.error = error.response?.data?.detail ||
                error.response?.data?.error ||
                '登录失败'
    console.error('登录错误:', error.response)
    return false
      }
    },
    async register(userData) {
      try {
        const response = await register(userData)
        this.token = response.data.token
        this.user = response.data.user
        this.isAuthenticated = true
        localStorage.setItem('token', response.data.token)
        return true
      } catch (error) {
        console.error('Registration failed:', error)
        return false
      }
    },
    async fetchProfile() {
      if (!this.token) return
      try {
        const response = await getProfile()
        this.user = response.data
      } catch (error) {
        console.error('Failed to fetch profile:', error)
        this.logout()
      }
    },
    logout() {
      this.token = null
      this.user = null
      this.isAuthenticated = false
      localStorage.removeItem('token')
    }
  }
})