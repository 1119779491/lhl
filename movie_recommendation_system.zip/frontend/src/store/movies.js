import { defineStore } from 'pinia'
import { fetchMovies, getMovieDetail, fetchGenres, searchMovies } from '@/api/movies'

export const useMovieStore = defineStore('movies', {
  state: () => ({
    movies: [],
    genres: [],
    currentMovie: null,
    loading: false,
    error: null
  }),
  actions: {
    async fetchMovies() {
      this.loading = true
      try {
        const response = await fetchMovies()
        this.movies = response.data
        this.error = null
      } catch (err) {
        this.error = '加载电影列表失败'
        console.error(err)
      } finally {
        this.loading = false
      }
    },

    async fetchMovieDetail(id) {
      this.loading = true
      try {
        const response = await getMovieDetail(id)
        this.currentMovie = response.data
        this.error = null
      } catch (err) {
        this.error = '加载电影详情失败'
        console.error(err)
      } finally {
        this.loading = false
      }
    },

    async fetchGenres() {
      try {
        const response = await fetchGenres()
        this.genres = response.data
      } catch (err) {
        console.error('加载电影类型失败:', err)
      }
    },

    async searchMovies(query) {
      this.loading = true
      try {
        const response = await searchMovies(query)
        this.movies = response.data
        this.error = null
      } catch (err) {
        this.error = '搜索失败'
        console.error(err)
      } finally {
        this.loading = false
      }
    }
  }
})