import { defineStore } from 'pinia'
import { fetchRecommendations, generateRecommendations } from '@/api/recommendations'

export const useRecommendationStore = defineStore('recommendations', {
  state: () => ({
    recommendations: [],
    loading: false,
    error: null,
    generating: false
  }),
  actions: {
    async fetchRecommendations() {
      this.loading = true
      try {
        const response = await fetchRecommendations()
        this.recommendations = response.data
        this.error = null
      } catch (err) {
        this.error = '获取推荐失败'
        console.error(err)
      } finally {
        this.loading = false
      }
    },

    async generateRecommendations() {
      this.generating = true
      try {
        await generateRecommendations()
        this.error = null
        return true
      } catch (err) {
        this.error = '生成推荐失败'
        console.error(err)
        return false
      } finally {
        this.generating = false
      }
    }
  }
})