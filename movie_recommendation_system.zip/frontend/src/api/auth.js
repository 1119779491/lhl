import api from '@/utils/api'

export const login = (credentials) => {
  return api.post('/api/auth/login/', credentials)
}

export const register = (userData) => {
  return api.post('/api/auth/register/', userData)
}

export const getProfile = () => {
  return api.get('/api/auth/profile/')
}

export const updateUserProfile = (data) => {
  return api.put('/api/auth/profile/', data)
}