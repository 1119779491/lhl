import api from '@/utils/api'

// 获取电影列表
export const fetchMovies = (params = {}) => {
  return api.get('/api/movies/', { params })
}

// 获取单个电影详情
export const getMovieDetail = (id) => {
  return api.get(`/api/movies/${id}/`)
}

// 获取所有电影类型
export const fetchGenres = () => {
  return api.get('/api/movies/genres/')
}

// 搜索电影
export const searchMovies = (query) => {
  return api.get('/api/movies/search/', { params: { query } })
}