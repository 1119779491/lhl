import axios from '@/utils/api'

export * from './auth'
export * from './movies'
export * from './recommendations'
export * from './interactions'