import api from '@/utils/api'

// 添加评分
export const addRating = (data) => {
  return api.post('/api/interactions/ratings/', data)
}

// 添加评论
export const addReview = (data) => {
  return api.post('/api/interactions/reviews/', data)
}

// 添加到观看历史
export const addToViewHistory = (movieId) => {
  return api.post('/api/interactions/history/', { movie: movieId })
}

// 获取用户观看历史
export const getUserHistory = () => {
  return api.get('/api/interactions/history/')
}

// 获取用户评分记录
export const getUserRatings = () => {
  return api.get('/api/interactions/ratings/')
}

// 获取电影评论
export const getReviews = (movieId) => {
  return api.get('/api/interactions/reviews/', {
    params: { movie: movieId }
  })
}