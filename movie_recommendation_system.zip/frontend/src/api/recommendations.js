import api from '@/utils/api'

export const fetchRecommendations = () => {
  return api.get('/api/recommendations/')
}

export const generateRecommendations = () => {
  return api.post('/api/recommendations/generate/')
}