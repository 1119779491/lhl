import json
import requests
import csv


def crawl_stock_data():
    # 目标URL
    url = "https://gushitong.baidu.com/opendata?openapi=1&dspName=iphone&tn=tangram&client=app&query=461000&code=461000&word=461000&resource_id=50748&market=ab&ma_ver=4&finClientType=pc"

    try:
        # 发送请求
        response = requests.get(url)
        response.raise_for_status()  # 检查请求是否成功

        # 解析JSON数据
        data = response.json()

        # 定位到contituents数据
        # 正确的数据路径: Result[1].DisplayData.resultData.tplData.result.tabs[0].content.contituents.list
        constituents = \
        data["Result"][1]["DisplayData"]["resultData"]["tplData"]["result"]["tabs"][0]["content"]["contituents"]["list"]

        # 保存数据到CSV文件
        with open('stock_data.csv', 'w', newline='', encoding='utf-8-sig') as f:
            writer = csv.writer(f)
            # 写入表头
            writer.writerow(['code', 'exchange', 'market', 'name', 'ratio_status', 'ratio_value'])

            # 写入数据行
            for stock in constituents:
                code = stock.get('code', '')
                exchange = stock.get('exchange', '')
                market = stock.get('market', '')
                name = stock.get('name', '')
                ratio_status = stock.get('ratio', {}).get('status', '')
                ratio_value = stock.get('ratio', {}).get('value', '')

                writer.writerow([code, exchange, market, name, ratio_status, ratio_value])

        print("数据已成功保存到stock_data.csv文件")

    except requests.exceptions.RequestException as e:
        print(f"请求出错: {e}")
    except KeyError as e:
        print(f"数据结构异常，缺少字段: {e}")
        print("请检查数据结构是否与代码中的访问路径一致")
    except json.JSONDecodeError:
        print("JSON解析失败，可能返回的不是JSON格式数据")
    except Exception as e:
        print(f"发生未知错误: {e}")


if __name__ == "__main__":
    crawl_stock_data()