import requests
import re
import csv

# 目标URL
url = "https://finance.pae.baidu.com/vapi/v2/blocks?style=tablelist&pn=0&rn=20&market=ab&typeCode=HY&finClientType=pc"
# 请求头（模拟浏览器，避免反爬）
headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/114.0.0.0"}

try:
    # 发送请求
    resp = requests.get(url, headers=headers)
    resp.raise_for_status()  # 检查请求是否成功
    resp_text = resp.text

    # 定义正则表达式提取code值
    obj = re.compile(r'"code"\s*:\s*"([^"]+)"', re.S)
    result = obj.findall(resp_text)

    # 准备CSV数据（将code列表转换为字典列表）
    data = [{"code": code} for code in result]
    fieldnames = ["code"]  # 定义CSV表头

    # 写入CSV文件
    with open("finance_data.csv", "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()  # 写入表头
        writer.writerows(data)  # 写入数据

    print(f"成功保存{len(result)}个code值到finance_data.csv")

except requests.exceptions.RequestException as e:
    print(f"请求出错: {e}")
except Exception as e:
    print(f"其他错误: {e}")