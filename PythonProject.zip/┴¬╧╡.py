import pandas as pd

persons_df = pd.DataFrame({
    '姓名': ['小李', '小王'],
    '职业': ['医生', '教师']
})

dummies = pd.get_dummies(persons_df['职业'])
print(dummies)