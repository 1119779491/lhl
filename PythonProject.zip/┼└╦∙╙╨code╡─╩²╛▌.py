import json
import requests
import csv
import time
import os

# 配置参数
CODE_FILE = "finance_data.csv"  # 存放所有code的CSV文件
OUTPUT_DIR = "stock_data"       # 输出目录
OUTPUT_FILE = os.path.join(OUTPUT_DIR, "all_stock_data.csv")  # 保存所有爬取数据的文件
DELAY_BETWEEN_REQUESTS = 1  # 请求间隔(秒)，避免频繁请求


def read_codes_from_csv(file_path):
    """从CSV文件中读取所有code"""
    codes = []
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            reader = csv.reader(f)
            # 跳过表头
            next(reader, None)
            # 读取code列（假设第一列是code）
            for row in reader:
                if row:
                    codes.append(row[0].strip())
        print(f"成功从{file_path}读取{len(codes)}个code")
        return codes
    except Exception as e:
        print(f"读取code文件失败: {e}")
        return []


def crawl_stock_data(code):
    """爬取单个code的详细数据"""
    try:
        # 构建请求URL，替换code
        url = f"https://gushitong.baidu.com/opendata?openapi=1&dspName=iphone&tn=tangram&client=app&query={code}&code={code}&word={code}&resource_id=50748&market=ab&ma_ver=4&finClientType=pc"

        # 发送请求
        response = requests.get(url)
        response.raise_for_status()
        data = response.json()

        # 定位contituents数据（使用你验证过的正确路径）
        constituents = \
        data["Result"][1]["DisplayData"]["resultData"]["tplData"]["result"]["tabs"][0]["content"]["contituents"]["list"]

        # 提取数据
        results = []
        for stock in constituents:
            item = {
                "block_code": code,  # 板块code
                "code": stock.get("code", ""),
                "exchange": stock.get("exchange", ""),
                "market": stock.get("market", ""),
                "name": stock.get("name", ""),
                "ratio_status": stock.get("ratio", {}).get("status", ""),
                "ratio_value": stock.get("ratio", {}).get("value", "")
            }
            results.append(item)

        return results

    except requests.exceptions.RequestException as e:
        print(f"请求code{code}数据失败: {e}")
        return []
    except KeyError as e:
        print(f"code{code}数据结构异常，缺少字段: {e}")
        return []
    except json.JSONDecodeError:
        print(f"code{code}响应不是JSON格式")
        return []
    except Exception as e:
        print(f"处理code{code}时发生错误: {e}")
        return []


def save_to_csv(data, first_batch=False):
    """保存数据到CSV文件"""
    if not data:
        return

    # 确保输出目录存在
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    try:
        with open(OUTPUT_FILE, 'a', newline='', encoding='utf-8-sig') as f:
            writer = csv.DictWriter(f, fieldnames=data[0].keys())

            # 如果是第一批数据，写入表头
            if first_batch:
                writer.writeheader()

            # 写入数据
            writer.writerows(data)

        print(f"已保存{len(data)}条记录到{OUTPUT_FILE}")

    except Exception as e:
        print(f"保存数据失败: {e}")


def main():
    """主函数"""
    # 1. 从CSV文件读取所有code
    codes = read_codes_from_csv(CODE_FILE)
    if not codes:
        print("未获取到code，程序退出")
        return

    print(f"开始爬取{len(codes)}个code的数据...")

    # 2. 批量爬取数据
    first_batch = True
    for i, code in enumerate(codes, 1):
        print(f"\n正在爬取第{i}/{len(codes)}个code: {code}...")
        results = crawl_stock_data(code)

        if results:
            save_to_csv(results, first_batch)
            first_batch = False  # 后续批次不写表头

        # 控制请求频率
        time.sleep(DELAY_BETWEEN_REQUESTS)

    print(f"\n所有数据爬取完成，数据已保存到{OUTPUT_FILE}")


if __name__ == "__main__":
    main()